﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Klasa
{
    public class OpremaServis
    {
        private IOprema _oprema;

        public OpremaServis(IOprema oprema)
        {
            _oprema = oprema;
        }

        public bool DodajNovInstrument(string tip, string proizvodjac, string naziv, int cena, DateTime? datumIznajmljivanja, DateTime? datumVracanja)
        {
            return _oprema.DodajInstrument(tip, proizvodjac, naziv, cena, datumIznajmljivanja, datumVracanja);
        }

        public bool IzmeniInstrument(int id, string tip, string proizvodjac, string naziv, int cena, DateTime? datumIznajmljivanja, DateTime? datumVracanja)
        {
            return _oprema.IzmeniInstrument(id, tip, proizvodjac, naziv, cena, datumIznajmljivanja, datumVracanja);
        }

        public bool ObrisiInstrument(int id)
        {
            return _oprema.ObrisiInstrument(id);
        }

        public DataTable PrikaziSveInstrumente()
        {
            return _oprema.PrikaziTabelu();
        }

        public DataTable PrikaziInstrumentePoCeni(int minCena, int maxCena)
        {
            return _oprema.PrikaziInstrumentePoCeni(minCena, maxCena);
        }

        public DataTable PrikaziInstrumentePoTipu(string tip)
        {
            return _oprema.PrikaziInstrumentePoTipu(tip);
        }
    }
}
