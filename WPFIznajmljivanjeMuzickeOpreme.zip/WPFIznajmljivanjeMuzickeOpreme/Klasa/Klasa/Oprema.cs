﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Klasa
{
    public class Oprema : IOprema
    {
        private SqlConnection konekcija;
        public string tip;
        public string proizvodjac;
        public string naziv;
        public int cena;
        public DateTime datumIznajmljivanja;
        public DateTime datumVracanja;

        public void OtvoriKonekciju()
        {
            if (konekcija.State == ConnectionState.Closed)
            {
                konekcija.Open();
            }
        }

        public void ZatvoriKonekciju()
        {
            if (konekcija.State == ConnectionState.Open)
            {
                konekcija.Close();
            }
        }

        public Oprema()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["BazaIznajmljivanjeMuzickeOpreme"].ConnectionString;
            konekcija = new SqlConnection(connectionString);
        }

        public DataTable PrikaziTabelu()
        {
            OtvoriKonekciju();
            SqlCommand komanda = new SqlCommand("SELECT * FROM [Oprema]", konekcija);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(komanda);
            DataTable tabela = new DataTable("Oprema");
            dataAdapter.Fill(tabela);
            ZatvoriKonekciju();

            return tabela;
        }

        public bool DodajInstrument(string tip, string proizvodjac, string naziv, int cena, DateTime? datumIznajmljivanja, DateTime? datumVracanja)
        {
            OtvoriKonekciju();
            SqlCommand komanda = new SqlCommand("INSERT INTO [Oprema](Tip, Proizvodjac, Naziv, Cena, Datum_iznajmljivanja, Datum_vracanja) VALUES(@Tip, @Proizvodjac, @Naziv, @Cena, @Datum_iznajmljivanja, @Datum_vracanja)", konekcija);
            komanda.Parameters.AddWithValue("@Tip", tip);
            komanda.Parameters.AddWithValue("@Proizvodjac", proizvodjac);
            komanda.Parameters.AddWithValue("@Naziv", naziv);
            komanda.Parameters.AddWithValue("@Cena", cena);
            komanda.Parameters.AddWithValue("@Datum_iznajmljivanja", datumIznajmljivanja ?? (object)DBNull.Value);
            komanda.Parameters.AddWithValue("@Datum_vracanja", datumVracanja ?? (object)DBNull.Value);

            int provera = komanda.ExecuteNonQuery();
            ZatvoriKonekciju();

            return provera == 1;
        }

        public bool IzmeniInstrument(int id, string tip, string proizvodjac, string naziv, int cena, DateTime? datumIznajmljivanja, DateTime? datumVracanja)
        {
            OtvoriKonekciju();
            SqlCommand komanda = new SqlCommand("UPDATE [Oprema] SET Tip = @Tip, Proizvodjac = @Proizvodjac, Naziv = @Naziv, Cena = @Cena, Datum_iznajmljivanja = @Datum_iznajmljivanja, Datum_vracanja = @Datum_vracanja WHERE ID_opreme = @ID_opreme", konekcija);
            komanda.Parameters.AddWithValue("ID_opreme", id);
            komanda.Parameters.AddWithValue("@Tip", tip);
            komanda.Parameters.AddWithValue("@Proizvodjac", proizvodjac);
            komanda.Parameters.AddWithValue("@Naziv", naziv);
            komanda.Parameters.AddWithValue("@Cena", cena);
            komanda.Parameters.AddWithValue("@Datum_iznajmljivanja", datumIznajmljivanja ?? (object)DBNull.Value);
            komanda.Parameters.AddWithValue("@Datum_vracanja", datumVracanja ?? (object)DBNull.Value);

            int provera = komanda.ExecuteNonQuery();
            ZatvoriKonekciju();

            return provera == 1;
        }

        public bool ObrisiInstrument(int id)
        {
            OtvoriKonekciju();
            SqlCommand komanda = new SqlCommand("DELETE FROM [Oprema] WHERE ID_opreme = @ID_opreme", konekcija);
            komanda.Parameters.AddWithValue("ID_opreme", id);

            int provera = komanda.ExecuteNonQuery();
            ZatvoriKonekciju();

            return provera == 1;
        }

        public DataTable PrikaziInstrumentePoCeni(int minCena, int maxCena)
        {
            OtvoriKonekciju();
            SqlCommand komanda = new SqlCommand("SELECT * FROM [Oprema] WHERE Cena BETWEEN @MinCena AND @MaxCena", konekcija);
            komanda.Parameters.AddWithValue("@MinCena", minCena);
            komanda.Parameters.AddWithValue("@MaxCena", maxCena);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(komanda);
            DataTable tabela = new DataTable("Oprema");
            dataAdapter.Fill(tabela);
            ZatvoriKonekciju();

            return tabela;
        }

        public DataTable PrikaziInstrumentePoTipu(string tip)
        {
            OtvoriKonekciju();
            SqlCommand komanda = new SqlCommand("SELECT * FROM [Oprema] WHERE Tip = @Tip", konekcija);
            komanda.Parameters.AddWithValue("@Tip", tip);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(komanda);
            DataTable tabela = new DataTable("Oprema");
            dataAdapter.Fill(tabela);
            ZatvoriKonekciju();

            return tabela;
        }
    }
}
