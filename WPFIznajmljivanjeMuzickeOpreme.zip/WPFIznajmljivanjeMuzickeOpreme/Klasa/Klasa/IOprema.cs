﻿using System.Data;
using System;
using System.Threading.Tasks;
using System.Threading;

namespace Klasa
{
    public interface IOprema
    {
        bool DodajInstrument(string tip, string proizvodjac, string naziv, int cena, DateTime? datumIznajmljivanja, DateTime? datumVracanja);
        bool IzmeniInstrument(int id, string tip, string proizvodjac, string naziv, int cena, DateTime? datumIznajmljivanja, DateTime? datumVracanja);
        bool ObrisiInstrument(int id);
        DataTable PrikaziTabelu();
        DataTable PrikaziInstrumentePoCeni(int minCena, int maxCena);
        DataTable PrikaziInstrumentePoTipu(string tip);
    }
}
