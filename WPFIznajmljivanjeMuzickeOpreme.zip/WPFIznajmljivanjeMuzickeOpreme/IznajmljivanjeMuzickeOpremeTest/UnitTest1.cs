using Moq;
using Klasa;
using Xunit;
using System;
using System.Data;

namespace TestProject
{
    public class UnitTest1
    {
        private readonly Mock<IOprema> _opremaMock;
        private readonly OpremaServis _opremaServis;

        public UnitTest1()
        {
            _opremaMock = new Mock<IOprema>();
            _opremaServis = new OpremaServis(_opremaMock.Object);
        }

        [Fact]
        public void TestDodajNovuOpremu()
        {
            // Arrange
            _opremaMock.Setup(o => o.DodajInstrument(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<DateTime?>(), It.IsAny<DateTime?>())).Returns(true);

            // Act
            bool result = _opremaServis.DodajNovInstrument("Gitara", "Yamaha", "FG800", 50000, null, null);

            // Assert
            Assert.True(result);
            _opremaMock.Verify(o => o.DodajInstrument("Gitara", "Yamaha", "FG800", 50000, null, null), Times.Once);
        }

        [Fact]
        public void TestObrisiOpremu()
        {
            // Arrange
            _opremaMock.Setup(o => o.ObrisiInstrument(It.IsAny<int>())).Returns(true);

            // Act
            bool result = _opremaServis.ObrisiInstrument(1);

            // Assert
            Assert.True(result);
            _opremaMock.Verify(o => o.ObrisiInstrument(1), Times.Once);
        }

        [Fact]
        public void TestObrisiNepostojecuOpremu()
        {
            // Arrange
            _opremaMock.Setup(o => o.ObrisiInstrument(It.IsAny<int>())).Throws(new KeyNotFoundException());

            // Act & Assert
            Assert.Throws<KeyNotFoundException>(() => _opremaServis.ObrisiInstrument(99));
            _opremaMock.Verify(o => o.ObrisiInstrument(99), Times.Once);
        }

        [Fact]
        public void TestIzmeniOpremu()
        {
            // Arrange
            _opremaMock.Setup(o => o.IzmeniInstrument(It.IsAny<int>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>(), It.IsAny<DateTime?>(), It.IsAny<DateTime?>())).Returns(true);

            // Act
            bool result = _opremaServis.IzmeniInstrument(1, "Klavir", "Yamaha", "U1", 150000, null, null);

            // Assert
            Assert.True(result);
            _opremaMock.Verify(o => o.IzmeniInstrument(1, "Klavir", "Yamaha", "U1", 150000, null, null), Times.Once);
        }

        [Fact]
        public void TestPrikaziSveInstrumente()
        {
            // Arrange
            var dataTable = new DataTable();
            dataTable.Columns.Add("ID_opreme", typeof(int));
            dataTable.Columns.Add("Tip", typeof(string));
            dataTable.Columns.Add("Proizvodjac", typeof(string));
            dataTable.Columns.Add("Naziv", typeof(string));
            dataTable.Columns.Add("Cena", typeof(int));
            dataTable.Columns.Add("Datum_iznajmljivanja", typeof(DateTime));
            dataTable.Columns.Add("Datum_vracanja", typeof(DateTime));

            dataTable.Rows.Add(1, "Gitara", "Yamaha", "FG800", 50000, DateTime.Now, DateTime.Now.AddDays(7));

            _opremaMock.Setup(o => o.PrikaziTabelu()).Returns(dataTable);

            // Act
            DataTable result = _opremaServis.PrikaziSveInstrumente();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.Rows.Count);
            _opremaMock.Verify(o => o.PrikaziTabelu(), Times.Once);
        }

        [Fact]
        public void TestPrikaziInstrumentePoCeni()
        {
            var dataTable = new DataTable();
            _opremaMock.Setup(o => o.PrikaziInstrumentePoCeni(It.IsAny<int>(), It.IsAny<int>())).Returns(dataTable);

            var result = _opremaServis.PrikaziInstrumentePoCeni(1000, 2000);

            Assert.NotNull(result);
            Assert.Equal(dataTable, result);
        }

        [Fact]
        public void TestPrikaziInstrumentePoTipu()
        {
            var dataTable = new DataTable();
            _opremaMock.Setup(o => o.PrikaziInstrumentePoTipu(It.IsAny<string>())).Returns(dataTable);

            var result = _opremaServis.PrikaziInstrumentePoTipu("Gitara");

            Assert.NotNull(result);
            Assert.Equal(dataTable, result);
        }
    }
}
