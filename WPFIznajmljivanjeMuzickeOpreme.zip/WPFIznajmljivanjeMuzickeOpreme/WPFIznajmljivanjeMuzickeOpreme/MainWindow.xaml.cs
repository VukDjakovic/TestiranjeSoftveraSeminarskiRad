﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
using System.Globalization;
using System.ComponentModel;
using System.Data.SqlTypes;
using Klasa;

namespace WPFIznajmljivanjeMuzickeOpreme
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            PrikaziTabelu();
        }

        private void PrikaziTabelu()
        {
            Oprema oprema = new Oprema();
            DataTable tabela = oprema.PrikaziTabelu();
            Tabela.ItemsSource = tabela.DefaultView;
        }

        private void ponistiUnos()
        {
            txtID_opreme.Text = "";
            cbxTip.SelectedValue = "";
            txtProizvodjac.Text = "";
            txtNaziv.Text = "";
            txtCena.Text = "";
            dtDatum_iznajmljivanja.Text = "";
            dtDatum_vracanja.Text = "";
        }

        private void Dodaj_Klik(object sender, RoutedEventArgs e)
        {
            Oprema oprema = new Oprema();
            bool unos = oprema.DodajInstrument(cbxTip.Text, txtProizvodjac.Text, txtNaziv.Text, int.Parse(txtCena.Text), dtDatum_iznajmljivanja.SelectedDate, dtDatum_vracanja.SelectedDate);
            
            if(unos)
            {
                MessageBox.Show("Podaci su uspešno upisani!");
                PrikaziTabelu();
            }
            else
            {
                MessageBox.Show("Greška prilikom unosa!");
            }
            ponistiUnos();
        }

        private void Tabela_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGrid dg = sender as DataGrid;
            DataRowView dr = dg.SelectedItem as DataRowView;
            if (dr != null)
            {
                txtID_opreme.Text = dr["ID_opreme"].ToString();
                cbxTip.Text = dr["Tip"].ToString();
                txtProizvodjac.Text = dr["Proizvodjac"].ToString();
                txtNaziv.Text = dr["Naziv"].ToString();
                txtCena.Text = dr["Cena"].ToString();
                dtDatum_iznajmljivanja.Text = dr["Datum_iznajmljivanja"].ToString();
                dtDatum_vracanja.Text = dr["Datum_vracanja"].ToString();
            }
        }

        private void Izmeni_Klik(object sender, RoutedEventArgs e)
        {
            Oprema oprema = new Oprema();
            bool izmena = oprema.IzmeniInstrument(int.Parse(txtID_opreme.Text), cbxTip.Text, txtProizvodjac.Text, txtNaziv.Text, int.Parse(txtCena.Text), dtDatum_iznajmljivanja.SelectedDate, dtDatum_vracanja.SelectedDate);

            if (izmena)
            {
                MessageBox.Show("Podaci su uspešno izmenjeni!");
                PrikaziTabelu();
            }
            else
            {
                MessageBox.Show("Greška prilikom izmene podataka!");
            }

            ponistiUnos();
        }

        private void Obrisi_Klik(object sender, RoutedEventArgs e)
        {
            Oprema oprema = new Oprema();
            bool brisanje = oprema.ObrisiInstrument(int.Parse(txtID_opreme.Text));

            if (brisanje)
            {
                MessageBox.Show("Podaci su uspešno obrisani!");
                PrikaziTabelu();
            }
            else 
            {
                MessageBox.Show("Greška prilikom brisanja podataka!");
            }

            ponistiUnos();
        }

        private void Filtriraj_Klik(object sender, RoutedEventArgs e)
        {
            ICollectionView prikazi = CollectionViewSource.GetDefaultView(Tabela.ItemsSource);
            prikazi.SortDescriptions.Clear();

            string izabranaCena = (cbxFilter_cena.SelectedItem as ComboBoxItem)?.Content.ToString();
            string izabraniTip = (cbxFilter_tip.SelectedItem as ComboBoxItem)?.Content.ToString();

            if (izabranaCena == "Od najniže")
            {
                prikazi.SortDescriptions.Add(new SortDescription("Cena", ListSortDirection.Ascending));
            }
            else if (izabranaCena == "Od najviše")
            {
                prikazi.SortDescriptions.Add(new SortDescription("Cena", ListSortDirection.Descending));
            }

            if (izabraniTip == "Abecedno uzlazno")
            {
                prikazi.SortDescriptions.Add(new SortDescription("Tip", ListSortDirection.Ascending));
            }
            else if (izabraniTip == "Abecedno silazno")
            {
                prikazi.SortDescriptions.Add(new SortDescription("Tip", ListSortDirection.Descending));
            }
        }
    }
}
